`
chmod +x ./scripts/script.sh
`

`
./scripts/script.sh
`
