## Среда


### Асинхронность: Event Loop, Promises



### Задания

- [fs на промисах ](../../../../core-async-promisify-fs)переписать на async-await
- [Star Wars](../../../../core-promises-star-wars)



### Вспомогательные источники
- [Симулятор Event Loop](http://latentflip.com/loupe)
- [Promise (learn.javascript.ru)](https://learn.javascript.ru/promise-basics)

**Видео:**
- [What the heck is the event loop?](https://www.youtube.com/watch?v=8aGhZQkoFbQ)



### Дополнительные задания

- [Todo List](../../../../to-do-list-JS)
> Отвлекись от промисов! Вспомини ООП!

- [JS OOP Racer](../../../../core-oop-promise-racer)
- Всё выполнил? Нужны ещё задания? Сообщи нам об этом!

### Материалы на завтра 
- [The Model-View-Controller ENG](../../../../mvc)
