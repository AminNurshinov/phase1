## Enumerable

`all`, `any`, `count`, `each_with_index`, `find`, `select`, `include`, `map`, `reduce`, `sort`, `sort_by`

## Array

`each`, `pop`, `push`, `shift`, `unshift`, `shuffle`, `sample`, `uniq`

## Hash

`each`, `fetch`, `keys`, `values`
