## Пятница

**Консольная игра (продолжаем работу)**

- [Бумеранг](../../../../core-async-boomerang)

### Общие рекомендации

[Как работать с командным проектом](https://github.com/Elbrus-Bootcamp/online-phase-1/blob/master/week-1/resources/challenge-all.md)