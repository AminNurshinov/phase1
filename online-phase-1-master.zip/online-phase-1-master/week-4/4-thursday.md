## Четверг

**Консольная игра**

- [Бумеранг](../../../../core-async-boomerang)

### Общие рекомендации

[Как работать с командным проектом](https://github.com/Elbrus-Bootcamp/online-phase-1/blob/master/resources/challenge-all.md)
