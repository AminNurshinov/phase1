## Среда

# *Экзамен!*

**Задания**
- [Комментарии](../../../../p1-sequelize-comments)
- [Футболки](../../../../p1-sequelize-shirts)
- [Курсы университета](../../../../p1-sequelize-university)


### Вспомогательные источники

- [model](https://sequelize.org/master/manual/model-querying-basics.html)
- [sequelize cli](https://sequelize.org/master/manual/migrations.html)
- [Associations](https://sequelize.org/master/manual/assocs.html)
- [Model Querying](https://sequelize.org/master/manual/model-querying-basics.html)
